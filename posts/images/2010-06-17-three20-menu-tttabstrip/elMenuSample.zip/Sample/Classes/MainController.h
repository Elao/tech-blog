//
//  MainController.h
//  Sample
//
//  Created by Guillaume chave on 16/06/10.
//  Copyright 2010 lyriance. All rights reserved.
//

@interface MainController : TTViewController <TTTabDelegate> 
{ 
	TTTabStrip * _tabBar;
	UILabel * label;
}

@end
