//
//  SampleAppDelegate.h
//  Sample
//
//  Created by Guillaume chave on 16/06/10.
//  Copyright lyriance 2010. All rights reserved.
//

@interface AppDelegate : NSObject <UIApplicationDelegate> {
}

@end

