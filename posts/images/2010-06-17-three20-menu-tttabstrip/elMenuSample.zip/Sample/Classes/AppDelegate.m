//
//  SampleAppDelegate.m
//  Sample
//
//  Created by Guillaume chave on 16/06/10.
//  Copyright lyriance 2010. All rights reserved.
//

#import "AppDelegate.h"
#import "MainController.h"


@interface MyStyleSheet : TTDefaultStyleSheet
@end

@implementation MyStyleSheet

- (TTStyle*)tabStrip {
	UIColor* border = [UIColor blackColor];
	return
    [TTReflectiveFillStyle styleWithColor:TTSTYLEVAR(tabTintColor) next:
	 [TTFourBorderStyle styleWithTop:nil right:nil bottom:border left:nil width:1 next:nil]];
}


- (UIColor*)tabBarTintColor {
	return RGBCOLOR(196, 51, 51);
}

- (UIColor*)navigationBarTintColor {
	return RGBCOLOR(196, 51, 51);
}

// background menu item
- (UIColor*)tabTintColor {
	return RGBCOLOR(255, 255, 255);
} 

@end




///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
@implementation AppDelegate


///////////////////////////////////////////////////////////////////////////////////////////////////
- (void)applicationDidFinishLaunching:(UIApplication *)application {
	TTNavigator* navigator = [TTNavigator navigator];
	navigator.persistenceMode = TTNavigatorPersistenceModeAll;

	TTURLMap* map = navigator.URLMap;

	
	MyStyleSheet * myStyleSheetInstance = [[MyStyleSheet alloc] init];
	
	// My OwnStyle
	[TTStyleSheet setGlobalStyleSheet:myStyleSheetInstance];
	
	[map from:@"*" toViewController:[TTWebController class]];
	
	[map from:@"tt://main" toSharedViewController:[MainController class]];
	
	if (![navigator restoreViewControllers]) {
		[navigator openURLAction:[TTURLAction actionWithURLPath:@"tt://main"]];
	}
}


///////////////////////////////////////////////////////////////////////////////////////////////////
- (BOOL)navigator:(TTNavigator*)navigator shouldOpenURL:(NSURL*)URL {
  return YES;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
- (BOOL)application:(UIApplication*)application handleOpenURL:(NSURL*)URL {
  [[TTNavigator navigator] openURLAction:[TTURLAction actionWithURLPath:URL.absoluteString]];
  return YES;
}


@end
