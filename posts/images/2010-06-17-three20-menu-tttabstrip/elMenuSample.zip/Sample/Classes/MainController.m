//
//  MainController.m
//  Sample
//
//  Created by Guillaume chave on 16/06/10.
//  Copyright 2010 lyriance. All rights reserved.
//

#import "MainController.h"



///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
@implementation MainController


-(void)viewDidLoad
{
	self.title = @"Menu Sample";
	
	_tabBar = [[TTTabStrip alloc] initWithFrame:CGRectMake(0, 0, 320, 41)];
	_tabBar.tabItems = [NSArray arrayWithObjects:
						 [[[TTTabItem alloc] initWithTitle:@"Menu 1"] autorelease], 
						 [[[TTTabItem alloc] initWithTitle:@"Menu 2"] autorelease], 
						[[[TTTabItem alloc] initWithTitle:@"Menu 3"] autorelease],
						[[[TTTabItem alloc] initWithTitle:@"Menu 4"] autorelease],
						[[[TTTabItem alloc] initWithTitle:@"Menu 5"] autorelease],
						[[[TTTabItem alloc] initWithTitle:@"Menu 6"] autorelease],
						[[[TTTabItem alloc] initWithTitle:@"Menu 7"] autorelease],
						[[[TTTabItem alloc] initWithTitle:@"Menu 8"] autorelease],
						[[[TTTabItem alloc] initWithTitle:@"Menu 9"] autorelease],
						 nil];
	_tabBar.delegate = self; 
	_tabBar.selectedTabIndex = 0;
	
	[self.view addSubview:_tabBar];  
	
	label = [[UILabel alloc] initWithFrame:CGRectMake(0, 150, 320, 50)];
	label.text = @"default text";
	
	label.font = [UIFont fontWithName:@"Arial" size:24];
	label.textAlignment = UITextAlignmentCenter;
	
	// First Menu is clicked
	[_tabBar setSelectedTabIndex:0];
	
	[self.view addSubview:label];
	
	
	
}

- (void)tabBar:(TTTabBar*)tabBar tabSelected:(NSInteger)selectedIndex
{    
	label.text = [NSString stringWithFormat:@"Menu %i",selectedIndex];
	
	switch (selectedIndex) {
		case 0: 
			label.text = @"Nice the first Menu"; 
			break; 
		case 1:
			label.text = @"Amazing the second Menu"; 
			break;  
	}
	
	
} 

@end

