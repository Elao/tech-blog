//
//  main.m
//  Sample
//
//  Created by Guillaume chave on 16/06/10.
//  Copyright lyriance 2010. All rights reserved.
//

int main(int argc, char *argv[]) {
  NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
  int retVal = UIApplicationMain(argc, argv, nil, @"AppDelegate");
  [pool release];
  return retVal;
}
