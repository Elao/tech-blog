#import <Three20/Three20.h>

@interface ImageTest1Controller : UIViewController {

}

@end

