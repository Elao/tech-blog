#import <Three20/Three20.h>

@interface PhotoTest1Controller : TTPhotoViewController
@end
