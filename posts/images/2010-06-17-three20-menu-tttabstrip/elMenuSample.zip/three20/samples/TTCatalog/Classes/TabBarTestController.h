#import <Three20/Three20.h>

@interface TabBarTestController : TTViewController {
  TTTabBar* _tabBar1;
  TTTabBar* _tabBar2;
  TTTabBar* _tabBar3;
}

@end
