#import <Three20/Three20.h>

@interface PhotoTest2Controller : TTThumbsViewController {
}

@end
