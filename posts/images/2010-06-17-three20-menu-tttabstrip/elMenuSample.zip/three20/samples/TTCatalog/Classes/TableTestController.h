#import <Three20/Three20.h>

@interface TableTestController : TTTableViewController
@end
